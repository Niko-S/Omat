import oope2018ht.omatluokat.UI;



/*
 *  Niko Sainio (sainio.niko.l@student.uta.fi)
 *  
 * 
 */
public class Oope2018HT {

    public static void main(String[] args) {

        UI.suorita();

    }

}
